/**
*
* This is the implementation of lazy binding that will help work around the adobe air security sandbox
* dependencies:
*	adobe air 	2.0+
*	jxf (dom)`	0.9
*/

if(!jxbinder){
	var jxbinder={}
}

jxbinder.read=function(location){
    var path    = (new air.File()).resolvePath(air.File.applicationDirectory.nativePath+'/html/'+location) ;
    var file    = new air.File('file:///'+path.nativePath) ;
    var istream = new air.FileStream();
    istream.open(file,air.FileMode.READ) ;
    var str     = istream.readMultiByte(file.size, air.File.systemCharset);
    istream.close() ;
    return str;
}

jxbinder.load=function(path,target){
	var html = jxbinder.read(path) ;
	jx.dom.set.value(target,html) ;
}
