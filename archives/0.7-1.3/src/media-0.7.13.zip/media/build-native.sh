adt -package -storetype pkcs12 -keystore e-launchpad.pfx -target native 3-launchpad.deb application-native.xml html icons


