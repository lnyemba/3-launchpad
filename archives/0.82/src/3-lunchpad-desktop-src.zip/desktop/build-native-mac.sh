$ADOBE_AIR_SDK/adt -package -storetype pkcs12 -keystore e-launchpad.pfx -target native 3-launchpad.dmg application-native.xml html icons


